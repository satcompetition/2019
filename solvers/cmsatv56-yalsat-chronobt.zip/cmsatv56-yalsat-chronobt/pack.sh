#!/bin/bash

set -e
set -x


# yalsat
./starexec_clean
cp starexec_description.txt-yalsat starexec_description.txt
(
cd bin
rm -f *
pwd
cp ../yalsat-run starexec_run_default
)
rm  -f   ../cmsat56_yalsat_chronobt.tar.gz
tar czvf ../cmsat56_yalsat_chronobt.tar.gz ./*

# walksat
./starexec_clean
cp starexec_description.txt-walksat starexec_description.txt
(
cd bin
rm -f *
pwd
cp ../walksat-run starexec_run_default
)
rm   -f  ../cmsat56_walksat_chronobt.tar.gz
tar czvf ../cmsat56_walksat_chronobt.tar.gz ./*

# finishup
./starexec_clean
