#ifndef _SHAWEI_H_
#define _SHAWEI_H_

#include "basis.h"

int diversification_shawei()
    {
    shawei_diversification_counter++;
    int i, k, c, v;
    int best_var;
    lit* clause_c;
    c = unsat_stack[rand() % unsat_stack_fill_pointer];
    clause_c = clause_lit[c];
    best_var = clause_c[0].var_num;
    for (k = 1; k < clause_lit_count[c]; ++k)
        {
        v = clause_c[k].var_num;

        //using score
        //if(score[v]>score[best_var]) best_var = v;
        //else if(score[v]==score[best_var]&&time_stamp[v]<time_stamp[best_var]) best_var = v;

        //using unweighted make
        if (unsat_app_count[v] > unsat_app_count[best_var]) best_var = v;
            //else if(unsat_app_count[v]==unsat_app_count[best_var] && time_stamp[v]<time_stamp[best_var]) best_var = v;
        else if (unsat_app_count[v] == unsat_app_count[best_var])
            {
            if (score[v] > score[best_var]) best_var = v;
            else if (score[v] == score[best_var] && time_stamp[v] < time_stamp[best_var]) best_var = v;
            }
        }
    return best_var;

    }
int aspiration_shawei() 
    {
    int i, k, c, v;
    int best_var;
    best_var = 0;
        for (i = 0; i < unsatvar_stack_fill_pointer; ++i)
            {
            if (score[unsatvar_stack[i]] > ave_weight)
                {
                best_var = unsatvar_stack[i];
                break;
                }
            }

        for (++i; i < unsatvar_stack_fill_pointer; ++i)
            {
            v = unsatvar_stack[i];
            if (score[v] > score[best_var]) best_var = v;
            else if (score[v] == score[best_var] && time_stamp[v] < time_stamp[best_var]) best_var = v;
            }
    return best_var;

    }




#endif