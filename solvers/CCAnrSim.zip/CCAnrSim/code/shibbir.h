#ifndef _SHIBBIR_H_
#define _SHIBBIR_H_


#include "basis.h"
#include "shawei.h"

/*path relinking process */
bool add_elite()
    {
    bool enoughEliteExists = false;

    if (step < elite_iteration[elite_pointer] + 10) //checks the while the states is most recent one
        return enoughEliteExists;

    if (elite_pointer == -1)
        {
        elite_pointer++;
        for (int v = 1; v <= num_vars; v++) //Save elite solution
            {
            if (fix[v] == 1) continue;
            elite[elite_pointer][v] = cur_soln[v];
            }
        elite_iteration[elite_pointer] = step;

        }
    else
        {
        bool similar = false; //indicates whether any saved solution is matched to the current one
        int len_elit = elite_pointer;
        if (elit_array_full)len_elit = MAX_ELITE_POINTER - 1;
        for (int ep = 0; ep <= len_elit; ep++)//checks all previous solution for similarity
            {
            int notEquals = 0;
            for (int v = 1; v <= num_vars; v++)
                {
                if (fix[v] == 1) continue;
                if (elite[ep][v] != cur_soln[v])
                    {
                    notEquals++;
                    }
                }
            float result = (notEquals * 100.0) / num_vars;
            if (result < sim_perameter)//if any solution is match for 80% then solution will not be saved
                {
                similar = true;
                break;
                }
            }
        if (!similar)
            {
            enoughEliteExists = true;
            if (elite_pointer == MAX_ELITE_POINTER - 1)//check array is full 
                {
                elite_pointer = -1;
                elit_array_full = true;
                }

            elite_pointer++;
            for (int v = 1; v <= num_vars; v++) //Save elite solution
                {
                if (fix[v] == 1) continue;
                elite[elite_pointer][v] = cur_soln[v];
                }
            elite_iteration[elite_pointer] = step;
            }
        }

    return enoughEliteExists;
    }

void add_iter_elite()  
    {  

    if (elite_pointer == -1)
        {
        elite_pointer++;
        for (int v = 1; v <= num_vars; v++) //Save elite solution
            {
            if (fix[v] == 1) continue;
            elite[elite_pointer][v] = cur_soln[v];
            }
        elite_iteration[elite_pointer] = step;

        }
    else
        {
        
        if (elite_pointer == MAX_ELITE_POINTER - 1)//check array is full 
            {
            elite_pointer = -1;
            elit_array_full = true;
            }

        elite_pointer++;
        for (int v = 1; v <= num_vars; v++) //Save elite solution
            {
            if (fix[v] == 1) continue;
            elite[elite_pointer][v] = cur_soln[v];
            }
        elite_iteration[elite_pointer] = step;

        }

    }

int path_relink()
    {
        
    int guideSol;
    int best_var;
    if (!elit_array_full)
        {
        
        //if(elite_pointer==0)guideSol=0;
         //if(elite_pointer==1)guideSol=rand()%2;
       // else
         guideSol=rand() % (elite_pointer);
        }
    else
        {
        guideSol = rand() % MAX_ELITE_POINTER; //randomly select a solution to re-link with current solution.
        while (elite_iteration[guideSol] == step) 
            guideSol = rand() % MAX_ELITE_POINTER;
        }
        //cout<<"line 125 gS "<<guideSol<< "best var "<< best_var<<endl;
    
    int max_score = INT_MIN;
    for (int v = 1; v <= num_vars; v++)//gives minimum index to flip
        {
        if (fix[v] == 1) continue;

        if (elite[guideSol][v] != cur_soln[v])
            {
            //cout<<"line 134: "<<score[v]<<" "<<max_score<< " bv "<<best_var<< endl;;
            if (score[v] > max_score)
                {
                //cout<<"y\n";
                max_score = score[v];
                best_var = v;
                }
            }
        }
    //cout<<"line 143: "<<best_var<<endl;
    return best_var;
    }
/*path relinking ends*/

/*similarity checking starts*/

int similiarity_checking(int flipvar)
    {
		
    if (similar_pointer == -1)
        {
        similar_pointer++;
        for (int v = 1; v <= num_vars; v++)
            {
            if (fix[v] == 1) continue; 
            similar_array[similar_pointer][v] = cur_soln[v];
            }
        }
    else
        {
            path_relink_counter++;
        bool s_flag = false; // true if any similarity occurs
        int len_similar = similar_pointer;
        if (similar_array_full)len_similar = MAX_SIMILAR_POINTER - 1;
        for (int sp = 0; sp <= len_similar; sp++)
            {

            int not_equals = 0;
            for (int v = 1; v <= num_vars; v++)
                {
                if (fix[v] == 1) continue;
                if (similar_array[sp][v] != cur_soln[v])
                    {
                    not_equals++;
                    }
                }
            float result = (not_equals * 100.0) / num_vars; //similar in percentage % 
            if (result < 10.0)//if more than 80% similar
                {
                flipvar = diversification_shawei();
                s_flag = true;
                break;
                }
            }

        if (!s_flag)// if solution is not discarded
            {
            if (similar_pointer == MAX_SIMILAR_POINTER - 1)
                {
                similar_array_full = true;
                similar_pointer = -1;
                }
            similar_pointer++;
            for (int v = 1; v <= num_vars; v++)
                {
                if (fix[v] == 1) continue;
                similar_array[similar_pointer][v] = cur_soln[v];
                }

            }
        }

    return flipvar;

    }

/*similarity checking ends*/


/* initialization machanism*/
void init_heuristic()
{
   
    /*shibbir initialization*/
    elit_array_full=false;
    elite_pointer=-1;
    similar_array_full = false;
    similar_pointer = -1;
    shawei_diversification_counter=0;
	path_relink_counter=0;
	goodvar_counter=0;
	aspiration_counter=0;
	diversification_to_goodvar_dis=0;
	last_divers=0;
    
    /*shawei prog starts   */
    
	int 		v,c;
	int		i,j;
	int		clause;
	
	//Initialize edge weights
	for (c = 0; c<num_clauses; c++)
		clause_weight[c] = 1;

	//init unsat_stack
	unsat_stack_fill_pointer = 0;
	unsatvar_stack_fill_pointer = 0;

	//init solution
	for (v = 1; v <= num_vars; v++) {
        
        if(fix[v]==0){
            if(real_var_score[v]>0)cur_soln[v]=1;
            else if(real_var_score[v]<0) cur_soln[v]=1;
            else cur_soln[v]=rand()%2;

/*
            if(rand()%2==1) cur_soln[v] = 1;
            else cur_soln[v] = 0;
*/
    		time_stamp[v] = 0;
			conf_change[v] = 1;
			unsat_app_count[v] = 0;
		
			//pscore[v] = 0;
		}
		
	}

	/* figure out sat_count, and init unsat_stack */
	for (c=0; c<num_clauses; ++c) 
	{
		if(clause_delete[c]==1) continue;
		
		sat_count[c] = 0;
		
		for(j=0; j<clause_lit_count[c]; ++j)
		{
			if (cur_soln[clause_lit[c][j].var_num] == clause_lit[c][j].sense)//checking random initial satisfaction
			{
				sat_count[c]++;
				sat_var[c] = clause_lit[c][j].var_num;	
			}
		}

		if (sat_count[c] == 0) 
			unsat(c);
	}

	/*figure out var score*/
	int lit_count;
	for (v=1; v<=num_vars; v++) 
	{
		if(fix[v]==1) 
		{
			score[v] = -100000;
			continue;
		}
		
		score[v] = 0;

		lit_count = var_lit_count[v];
		
		for(i=0; i<lit_count; ++i)
		{
			c = var_lit[v][i].clause_num;
			if (sat_count[c]==0) score[v]++;
			else if (sat_count[c]==1 && var_lit[v][i].sense==cur_soln[v]) score[v]--;
		}
	}
	
		
	//init goodvars stack
	goodvar_stack_fill_pointer = 0;
	for (v=1; v<=num_vars; v++) 
	{
		if(fix[v]==1)  continue;
		if(score[v]>0)// && conf_change[v]==1)
		{
			already_in_goodvar_stack[v] = 1;
			pushh(v,goodvar_stack);
			
		}
		else already_in_goodvar_stack[v] = 0;
	}
	
	//setting for the virtual var 0
	time_stamp[0]=0;
	//pscore[0]=0;
	
	this_try_best_unsat_stack_fill_pointer = unsat_stack_fill_pointer;

}


#endif
