/*************************************************************************************************
Candy -- Copyright (c) 2015-2019, Markus Iser, KIT - Karlsruhe Institute of Technology

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 **************************************************************************************************/

#include "candy/gates/GateAnalyzer.h"
#include "candy/core/CandySolverInterface.h"
#include "candy/core/CNFProblem.h"
#include "candy/utils/MemUtils.h"
#include "candy/core/CandySolverInterface.h"
#include "candy/frontend/CandyBuilder.h"

#include <iterator>
#include <vector>

namespace Candy {

GateAnalyzer::GateAnalyzer(const CNFProblem& dimacs, double timeout, int tries, bool patterns, bool semantic, bool holistic, 
        bool lookahead, bool intensify, int lookahead_threshold, unsigned int conflict_budget) :
            problem (dimacs), runtime(timeout), 
            maxTries (tries), usePatterns (patterns), useSemantic (semantic || holistic),
            useHolistic (holistic), useLookahead (lookahead), useIntensification (intensify),
            lookaheadThreshold(lookahead_threshold), semanticConflictBudget(conflict_budget), 
            artificialRoot(nullptr)
{
    runtime.start();
    gates.resize(problem.nVars());
    inputs.resize(2 * problem.nVars(), false);
    index.resize(2 * problem.nVars());
    for (Cl* c : problem) for (Lit l : *c) {// build index
        index[l].push_back(c);
    }
    solver = createSolver(); 
    if (useHolistic) solver->init(problem);
    runtime.stop();
}

GateAnalyzer::~GateAnalyzer() {
    if (hasArtificialRoot()) {
        delete artificialRoot;
    }
}

std::vector<Lit> GateAnalyzer::getRarestLiterals(std::vector<For>& index) {
    std::vector<Lit> result;
    unsigned int min = UINT_MAX;
    for (Lit l = Lit(0, false); l.x < (int32_t)index.size(); l.x++) {
        if (index[l].size() > 0 && index[l].size() < min) {
            min = index[l].size();
            result.clear();
            result.push_back(l);
        }
        else if (index[l].size() == min) {
            result.push_back(l);
        }
    }
    return result;
}

std::vector<Cl*> GateAnalyzer::getBestRoots() {
    std::vector<Cl*> clauses;
    std::vector<Lit> lits = getRarestLiterals(index);
    if (lits.empty()) return clauses;
    Lit best = lits.back();
//    int weight = 0;
//    for (Lit lit : lits) {
//        std::vector<Lit> others;
//        for (Cl* clause : index[lit]) {
//            others.insert(others.end(), clause->begin(), clause->end());
//        }
//        sort(others.begin(), others.end());
//        others.erase(std::unique(others.begin(), others.end()), others.end());
//        auto end = remove_if(others.begin(), others.end(), [lits] (Lit lit) { return std::find(lits.begin(), lits.end(), lit) == lits.end(); });
//
//        if (std::distance(end, others.end()) < weight) {
//            weight = std::distance(end, others.end());
//            best = lit;
//        }
//    }
    clauses.insert(clauses.end(), index[best].begin(), index[best].end());
    index[best].clear();
    removeFromIndex(index, clauses);
    return clauses;
}

bool GateAnalyzer::semanticCheck(Var o, For& fwd, For& bwd) {
    CNFProblem constraint;
    Lit alit = Lit(problem.nVars()+assumptions.size(), false);
    assumptions.push_back(~alit);
    Cl clause;
    for (const For& f : { fwd, bwd }) {
        for (Cl* cl : f) {
            for (Lit l : *cl) {
                if (l.var() != o) {
                    clause.push_back(l);
                }
            }
            clause.push_back(alit);
            constraint.readClause(clause);
            clause.clear();
        }
    }
    solver->init(constraint);
    solver->setTermCallback(solver, [](void* solver) -> int { // todo: use semantic-conflict-budget
        return ((CandySolverInterface*)solver)->getStatistics().nConflicts() > 1000; 
    });
    solver->setAssumptions(assumptions);
    bool isRightUnique = solver->solve() == l_False;
    assumptions.back() = alit;
    return isRightUnique;
}


// clause patterns of full encoding
bool GateAnalyzer::patternCheck(Lit o, For& fwd, For& bwd, std::set<Lit>& inp) {
    // precondition: fwd blocks bwd on the o

    // check if fwd and bwd constrain exactly the same inputs (in opposite polarity)
    std::set<Lit> t;
    for (Cl* c : bwd) for (Lit l : *c) if (l != o) t.insert(~l);
    if (inp != t) return false;

    bool fullOr = fwd.size() == 1 && fixedClauseSize(bwd, 2);
    bool fullAnd = bwd.size() == 1 && fixedClauseSize(fwd, 2);
    if (fullOr || fullAnd) return true;

    // given a total of 2^n blocked clauses if size n+1 with n times the same variable should imply that we have no redundancy in the n inputs
    if (fwd.size() == bwd.size() && 2*fwd.size() == pow(2, inp.size()/2)) {
        std::set<Var> vars;
        for (Lit l : inp) vars.insert(l.var());
        return 2*vars.size() == inp.size();
    }

    return false;
}

// main analysis routine
std::vector<Lit> GateAnalyzer::analyze(std::vector<Lit>& candidates, bool pat, bool sem, bool lah) {
    std::vector<Lit> frontier, remainder;

    for (Lit o : candidates) {
        For& f = index[~o], g = index[o];
        if (!runtime.hasTimeout() && f.size() > 0 && (isBlocked(o, f, g) || (lah && isBlockedAfterVE(o, f, g)))) {
            bool mono = false, pattern = false, semantic = false;
            std::set<Lit> inp;
            for (Cl* c : f) for (Lit l : *c) if (l != ~o) inp.insert(l);
            mono = inputs[o] == 0 || inputs[~o] == 0;
            if (!mono) pattern = pat && patternCheck(o, f, g, inp);
            if (!mono && !pattern) semantic = sem && semanticCheck(o.var(), f, g);
#ifdef GADebug
            if (mono) printf("Candidate output %s%i is nested monotonically\n", o.sign()?"-":"", o.var()+1);
            if (pattern) printf("Candidate output %s%i matches pattern\n", o.sign()?"-":"", o.var()+1);
            if (semantic) printf("Candidate output %s%i passed semantic test\n", o.sign()?"-":"", o.var()+1);
#endif
            if (mono || pattern || semantic) {
                nGates++;
                frontier.insert(frontier.end(), inp.begin(), inp.end());
                for (Lit l : inp) {
                    inputs[l]++;
                    if (!mono) inputs[~l]++;
                }
                //###
                gates[o.var()].out = o;
                gates[o.var()].notMono = !mono;
                gates[o.var()].fwd.insert(gates[o.var()].fwd.end(), f.begin(), f.end());
                gates[o.var()].bwd.insert(gates[o.var()].bwd.end(), g.begin(), g.end());
                gates[o.var()].inp.insert(gates[o.var()].inp.end(), inp.begin(), inp.end());
                //###
                removeFromIndex(index, f);
                removeFromIndex(index, g);
            }
            else {
                remainder.push_back(o);
            }
        }
        else {
            remainder.push_back(o);
        }
    }

    candidates.swap(remainder);

    return frontier;
}

/**
 * Execute after analysis in order to
 * tronsform many roots to one big and gate with one output
 * Side-effect: introduces a fresh variable
 */
Lit GateAnalyzer::normalizeRoots() {
    if (roots.size() > 1 || (*roots.begin())->size() > 1) {
        Var root = problem.nVars();
        // grow data-structures
        gates.resize(problem.nVars() + 1);
        inputs.resize(2 * problem.nVars() + 2, false);
        // create gate
        nGates++;
        gates[root].out = Lit(root, false);
        gates[root].notMono = false;
        std::set<Lit> inp;
        for (Cl* c : roots) {
            inp.insert(c->begin(), c->end());
            c->push_back(Lit(root, true));
            gates[root].fwd.push_back(c);
        }
        gates[root].inp.insert(gates[root].inp.end(), inp.begin(), inp.end());
        this->roots.clear();
        artificialRoot = new Cl();
        artificialRoot->push_back(gates[root].out);
        this->roots.push_back(artificialRoot);
        assert(this->roots.size() == 1);
        return gates[root].out;
    }
    else {
        return *(*roots.begin())->begin();
    }
}

std::vector<Lit> GateAnalyzer::getRootLiterals() {
    std::vector<Lit> literals;

    for (Cl* c : getRoots()) {
        literals.insert(literals.end(), c->begin(), c->end());
    }
    std::sort(literals.begin(), literals.end());
    auto last = std::unique(literals.begin(), literals.end());
    literals.erase(last, literals.end());

    return literals;
}

/**
 * @brief GateAnalyzer::getPrunedProblem
 * @param model
 * @return clauses of all satisfied branches
 */
For GateAnalyzer::getPrunedProblem(Cl model) {
    For result(this->roots.begin(), this->roots.end());

    std::vector<Lit> literals = getRootLiterals();
    std::vector<int> visited(model.size(), -1);

    while (literals.size() > 0) {
        Lit o = literals.back();
        literals.pop_back();

        if (model[o.var()] == o && visited[o.var()] != o) {
            Gate gate = gates[o.var()];
            result.insert(result.end(), gate.fwd.begin(), gate.fwd.end());
            result.insert(result.end(), gate.bwd.begin(), gate.bwd.end());
            literals.insert(literals.end(), gate.inp.begin(), gate.inp.end());
            visited[o.var()] = o;
        }
    }

    return result;
}

void GateAnalyzer::analyze(std::vector<Lit>& candidates) {
    if (useIntensification) {
        std::vector<Lit> remainder;
        bool patterns = false, semantic = false, lookahead = false, restart = false;
        for (int level = 0; level < 3 && !runtime.hasTimeout(); restart ? level = 0 : level++) {
#ifdef GADebug
            printf("Remainder size: %zu, Intensification level: %i\n", remainder.size(), level);
#endif

            restart = false;

            switch (level) {
            case 0: patterns = true; semantic = false; lookahead = false; break;
            case 1: patterns = false; semantic = true; lookahead = false; break;
            case 2: patterns = false; semantic = true; lookahead = true; break;
            default: assert(level >= 0 && level < 3); break;
            }

            if (!usePatterns && patterns) continue;
            if (!useSemantic && semantic) continue;
            if (!useLookahead && lookahead) continue;

            candidates.insert(candidates.end(), remainder.begin(), remainder.end());
            remainder.clear();

            while (candidates.size() && !runtime.hasTimeout()) {
                std::vector<Lit> frontier = analyze(candidates, patterns, semantic, lookahead);
                if (level > 0 && frontier.size() > 0) restart = true;
                remainder.insert(remainder.end(), candidates.begin(), candidates.end());
                candidates.swap(frontier);
            }

            sort(remainder.begin(), remainder.end());
            remainder.erase(unique(remainder.begin(), remainder.end()), remainder.end());
            reverse(remainder.begin(), remainder.end());
        }
    }
    else {
        while (candidates.size() && !runtime.hasTimeout()) {
            std::vector<Lit> frontier = analyze(candidates, usePatterns, useSemantic, useLookahead);
            candidates.swap(frontier);
        }
    }
}

void GateAnalyzer::analyze() {
    std::vector<Lit> next;

    runtime.start();

    // start recognition with unit literals
    for (Cl* c : problem) {
        if (c->size() == 1) {
            roots.push_back(c);
            removeFromIndex(index, c);
            next.push_back((*c)[0]);
            inputs[(*c)[0]]++;
        }
    }

    analyze(next);

    // clause selection loop
    for (int k = 0; k < maxTries && !runtime.hasTimeout(); k++) {
        std::vector<Cl*> clauses = getBestRoots();
        roots.insert(roots.end(), clauses.begin(), clauses.end());
        for (Cl* c : clauses) {
            next.insert(next.end(), c->begin(), c->end());
            for (Lit l : *c) inputs[l]++;
        }
        analyze(next);
    }

    runtime.stop();
}

/**
  * Experimental: Tries to detect a common sub-gate in order to decode a gate
  */
// precondition: ~o \in f[i] and o \in g[j]
bool GateAnalyzer::isBlockedAfterVE(Lit o, For& f, For& g) {
    // generate set of non-tautological resolvents
    
    std::vector<Cl> resolvents;
    for (Cl* a : f) for (Cl* b : g) {
        if (!isBlocked(o, *a, *b)) {
            resolvents.resize(resolvents.size() + 1); // new clause gets created at the back
            Cl& res = resolvents.back();
            res.insert(res.end(), a->begin(), a->end());
            res.insert(res.end(), b->begin(), b->end());
            res.erase(std::remove_if(res.begin(), res.end(), [o](Lit l) { return l.var() == o.var(); }), res.end());
        }
        if ((int)resolvents.size() > lookaheadThreshold) return false;
    }
    if (resolvents.empty()) return true; // the set is trivially blocked

#ifdef GADebug
    printf("Found %zu non-tautologic resolvents\n", resolvents.size());
#endif

    // generate set of literals whose variable occurs in every non-taut. resolvent (by successive intersection of resolvents)
    std::vector<Var> candidates;
    for (Lit l : resolvents[0]) candidates.push_back(l.var());
    for (size_t i = 1; i < resolvents.size(); ++i) {
        if (candidates.empty()) break;
        std::vector<Var> next_candidates;
        for (Lit lit : resolvents[i]) {
            if (find(candidates.begin(), candidates.end(), lit.var()) != candidates.end()) {
                next_candidates.push_back(lit.var());
            }
        }
        std::swap(candidates, next_candidates);
        next_candidates.clear();
    }
    if (candidates.empty()) return false; // no candidate output

#ifdef GADebug
    printf("Found %zu candidate variables for functional elimination: ", candidates.size());
    for (Var v : candidates) printf("%i ", v+1);
    printf("\n");
#endif

    // generate set of input variables of candidate gate (o, f, g)
    std::vector<Var> inputs;
    std::vector<int> occCount(problem.nVars()+1);
    for (For formula : { f, g })  for (Cl* c : formula)  for (Lit l : *c) {
        if (l.var() != o.var()) {
            inputs.push_back(l.var());
            occCount[l.var()]++;
        }
    }

    sort(inputs.begin(), inputs.end());
    inputs.erase(unique(inputs.begin(), inputs.end()), inputs.end());

    sort(candidates.begin(), candidates.end(), [occCount](Var a, Var b) { return occCount[a] < occCount[b]; });

    for (Var cand : candidates) {
        // generate candidate definition for output
        For fwd, bwd;
        Lit out = Lit(cand, false);

#ifdef GADebug
        printf("candidate variable: %i\n", cand+1);
#endif

        for (Lit lit : { out, ~out })
            for (Cl* c : index[lit]) {
                // clauses of candidate gate (o, f, g) are still part of index (skip them)
                if (find(f.begin(), f.end(), c) == f.end() && find(g.begin(), g.end(), c) == g.end()) {
                    // use clauses that constrain the inputs of our candidate gate only
                    bool is_subset = true;
                    for (Lit l : *c) {
                        if (find(inputs.begin(), inputs.end(), l.var()) == inputs.end()) {
                            is_subset = false;
                            break;
                        }
                    }
                    if (is_subset) {
                        if (lit == ~out) fwd.push_back(c);
                        else bwd.push_back(c);
                    }
                }
            }

#ifdef GADebug
        printf("Found %zu clauses for candidate variable %i\n", fwd.size() + bwd.size(), cand+1);
#endif

        // if candidate definition is functional
        if ((fwd.size() > 0 || bwd.size() > 0) && isBlocked(out, fwd, bwd) && semanticCheck(cand, fwd, bwd)) {
            // split resolvents by output literal 'out' of the function defined by 'fwd' and 'bwd'
            For res_fwd, res_bwd;
            for (Cl& res : resolvents) {
                if (find(res.begin(), res.end(), ~out) != res.end()) {
                    res_fwd.push_back(&res);
                } else {
                    res_bwd.push_back(&res);
                }
            }
            if ((res_fwd.size() == 0 || bwd.size() > 0) && (res_bwd.size() == 0 || fwd.size() > 0))
                if (isBlocked(out, res_fwd, bwd) && isBlocked(~out, res_bwd, fwd)) {
#ifdef GADebug
                    printf("Blocked elimination found for candidate variable %i\n", cand+1);
#endif
                    return true;
                }
        }
    }

    return false;
}

bool GateAnalyzer::hasTimeout() const {
    return runtime.hasTimeout();
}

}
