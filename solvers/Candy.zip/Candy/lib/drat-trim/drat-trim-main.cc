#include "drat-trim.cc"

int main (int argc, char** argv) {
  struct solver S;

  S.inputFile  = NULL;
  S.proofFile  = stdin;
  S.coreStr    = NULL;
  S.activeFile = NULL;
  S.lemmaStr   = NULL;
  S.lratFile   = NULL;
  S.traceFile  = NULL;
  S.nReads     = 0;
  S.nWrites    = 0;
  S.mask       = 0;
  S.verb       = 0;
  S.delProof   = 0;
  S.backforce  = 0;
  S.optimize   = 0;
  S.warning    = 0;
  S.prep       = 0;
  S.mode       = BACKWARD_UNSAT;
  S.ignoreDel  = 1;
  S.reduce     = 1;
  S.binMode    = 0;
  S.binOutput  = 0;

  int i, tmp = 0;
  for (i = 1; i < argc; i++) {
    if        (argv[i][0] == '-') {
      if      (argv[i][1] == 'h') printHelp ();
      else if (argv[i][1] == 'c') S.coreStr    = argv[++i];
      else if (argv[i][1] == 'a') S.activeFile = fopen (argv[++i], "w");
      else if (argv[i][1] == 'l') S.lemmaStr   = argv[++i];
      else if (argv[i][1] == 'L') S.lratFile   = fopen (argv[++i], "w");
      else if (argv[i][1] == 'r') S.traceFile  = fopen (argv[++i], "w");
      else if (argv[i][1] == 'B') S.backforce  = 1;
      else if (argv[i][1] == 'O') S.optimize   = 1;
      else if (argv[i][1] == 'C') S.binOutput  = 1;
      else if (argv[i][1] == 'D') S.delProof   = 1;
      else if (argv[i][1] == 'u') S.mask       = 1;
      else if (argv[i][1] == 'v') S.verb       = 1;
      else if (argv[i][1] == 'w') S.warning    = NOWARNING;
      else if (argv[i][1] == 'W') S.warning    = HARDWARNING;
      else if (argv[i][1] == 'p') S.ignoreDel  = 0;
      else if (argv[i][1] == 'R') S.reduce     = 0;
      else if (argv[i][1] == 'f') S.mode       = FORWARD_UNSAT;
      else if (argv[i][1] == 'S') S.mode       = FORWARD_SAT; }
    else {
      tmp++;
      if (tmp == 1) {
        S.inputFile = fopen (argv[1], "r");
        if (S.inputFile == NULL) {
          printf ("\rc error opening \"%s\".\n", argv[i]); return ERROR; } }

      else if (tmp == 2) {
        S.proofFile = fopen (argv[2], "r");
        if (S.proofFile == NULL) {
          printf ("\rc error opening \"%s\".\n", argv[i]); return ERROR; }

        int j;
        for (j = 0; j < 10; j++) {
          int c = getc(S.proofFile);
          if (c == EOF) break;
          if ((c != 100) && (c != 10) && (c != 13) && (c != 32) && (c != 45) && ((c < 48) || (c > 57)) && ((c < 65) || (c > 122)))  {
            printf ("\rc turning on binary mode checking\n");
            S.binMode = 1; break; } }
        fclose (S.proofFile);
        S.proofFile = fopen (argv[2], "r");
        if (S.proofFile == NULL) {
          printf ("\rc error opening \"%s\".\n", argv[i]); return ERROR; } } } }

  if (tmp == 1) printf ("\rc reading proof from stdin\n");
  if (tmp == 0) printHelp ();

  int parseReturnValue = parse (&S);

  fclose (S.inputFile);
  fclose (S.proofFile);

  if (S.mode == FORWARD_UNSAT) {
    S.reduce = 0; }

  if (S.delProof && argv[2] != NULL) {
    int ret = remove(argv[2]);
    if (ret == 0) printf("c deleted proof %s\n", argv[2]); }

  int sts = ERROR;
  if       (parseReturnValue == ERROR)          printf ("\rs MEMORY ALLOCATION ERROR\n");
  else if  (parseReturnValue == UNSAT)          printf ("\rc trivial UNSAT\ns VERIFIED\n");
  else if  ((sts = verify (&S, -1, -1)) == UNSAT) printf ("\rs VERIFIED\n");
  else printf ("\rs NOT VERIFIED\n");

  if (S.optimize) {
    printf("c proof optimization started (ignoring the timeout)\n");
    int iteration = 1;
//    while (iteration < 20) {
    while (S.nRemoved) {
      deactivate (&S);
      shuffleProof (&S, iteration);
      iteration++;
      verify (&S, 0, 0); } }

  freeMemory (&S);
  return (sts != UNSAT); // 0 on success, 1 on any failure
}