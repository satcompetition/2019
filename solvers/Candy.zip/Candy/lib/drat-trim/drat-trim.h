#ifndef _DRAT_TRIM_H
#define _DRAT_TRIM_H

extern int check_proof(char* input_file, char* proof_file);

#endif // _DRAT_TRIM_H